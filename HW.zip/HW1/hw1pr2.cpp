
#include <ctime>
#include "std_lib_facilities_3.h"
#include "Matrix.h"
#include "MatrixIO.h"

clock_t t1,t2; //global timing variables

vector<vector<int>> init_vec(int n){

    vector<vector<int>> v(n);
    vector<int> v_2(n);

    for (int x=0;x<n;++x){ // my original implementation used push_back on vector of size 0
        for(int i=0;i<n;++i){ //but for large n this was extremely slow
            v_2[i]=(rand()%1000);
            }
        v[x]=(v_2);
        }

    return v;
}

Numeric_lib::Matrix<int,2> init_mat(int n){

    Numeric_lib::Matrix<int,2> m(n,n); // declare matrix
    Numeric_lib::Index in=n;

    for (Numeric_lib::Index x=0;x<in;++x){
        for (Numeric_lib::Index i=0;i<in;++i){
            m(x,i)=rand()%1000;
}
}
    return m;
}

int num_additions(Numeric_lib::Matrix<int,2> m){
    t1=clock();
    int total=0;
    int avg=0;
    for(int t=0;t<5000;++t){
        if( m.dim1()>900)//break for larger n, to keep program from seemingly unending
            t=10000;
        total=0;
        avg=0;
    for (Numeric_lib::Index x=0;x<m.dim1();++x){
      for (Numeric_lib::Index i=0;i<m.dim2();++i){
            avg=avg+m(x,i);
            ++total;
    }
    }
    }
    t2=clock();
    double calc_time=(t2-t1);
    cout<<"5000 iterations for timing purposes, 1 iteration for n=1000, 10000 \n";
    cout<<"total clocks for all iterations = "<<calc_time<< " at "<<CLOCKS_PER_SEC<<" clocks per second "<<endl;
    cout<<"iteration time!= "<<(calc_time/CLOCKS_PER_SEC)/10000<<" seconds"<<endl;
    avg=avg/total;
    cout<<"average of all elements is "<<avg<<endl;
    cout<<"number of additions required is "<<
    total<<endl;
    return total;
}

int num_additions(vector<vector<int>> v){
    t1=clock();
    int total=0;
    int avg=0;
    for(int t=0;t<5000;++t){
        if( v.size()>900)//break for larger n, to keep program from seemingly unending
            t=10000;
        total=0;
        avg=0;
        for (int x=0;x<v.size();++x){
            for (int i=0;i<v.size();++i){
                avg=avg+v[x][i];
                ++total;
                }
            }
        }
    t2=clock();
    double calc_time=(t2-t1);
    cout<<"5000 iterations for timing purposes, 1 iteration for n=1000, 10000 \n";
    cout<<"total clocks for all iterations = "<<calc_time<< " at "<<CLOCKS_PER_SEC<<" clocks per second "<<endl;
    cout<<"iteration time!= "<<(calc_time/CLOCKS_PER_SEC)/10000<<" seconds"<<endl;
    avg=avg/total;
    cout<<"average of all elements is "<<avg<<endl;
    cout<<"number of additions required is "<<
    total<<endl;

    return total;
}




int main()
try
{   int n=10;
    cout<<"each implementation uses different random ints\n";

while(n<10001){

    vector<vector<int>> vec_1=init_vec(n); //initialize classes with random integers
    Numeric_lib::Matrix<int,2> mat_1=init_mat(n);

    cout<<"\nN= "<<n<<"\n\nVector:\n\n";

    num_additions(vec_1);

    cout<<"\nMatrix:\n\n";

    num_additions(mat_1);

    if (n==10)
        n=20;
    else
        if (n==20)
            n=100;
        else
            n=n*10;

}



return 0;
}

catch(...){
cout<<"exception occured!\n";
return 2;}
