
#include "std_lib_facilities_3.h"

#include "std_lib_facilities_3.h"

char delim;//global option variable and counter
int counter;

int max(int n)  //formula to calculate worst case scenario number of guesses
{
    return (log(n)/log(2))+1;
}

int query(int& range_1, int& range_2)
{
    int g=0;
    if (delim!='a')
    {
        cout<<"input a guess between "<<range_1<<" and "<<range_2<<endl;
        cout<<"hint: the midpoint is "<<(range_1+range_2)/2<<endl;
        cin>>g;
    }
    else
    {
        if((range_2-range_1)==1&&range_2!=2) //computer guessing algorithim
            g=range_2;
        else
            g=(range_1+range_2)/2;
    }
    if (counter==2&&range_2==2)
        g=range_2;
    if(g<range_1||g>range_2)
        throw 1;
    return g;
}

int comparison(int&n, int&guess)
{
    if (guess<n)
    {
        cout<<"guess was lower.\n";
        return 1;
    }
    if (guess>n)
    {
        cout<<"guess was higher.\n";
        return 2;
    }
    if (guess==n)
    {
        cout<<"guess was correct!\n\n";
        return 3;
    }
}

vector<int> find_num(int range_2)
{
    vector<int> results;
    for (int x=0; x<2; ++x)
    {
        results.push_back(range_2);
        counter=0;
        int flag=0;
        int range_1=1;
        int number=1;

        if (range_2!=1)
        {
            number=range_2-x;
        }
        cout<<"Lets play a game. Guess the Number!";
        while(flag!=3)
        {
            ++counter;
            int guess=query(range_1,range_2);
            flag=comparison(number,guess);
            if (flag==1)
                range_1=guess;
            if (flag==2)
                range_2=guess;
        }

        results.push_back(number);
        results.push_back(counter);
        if (range_2==1)
            x=2;

    }
    return results;

}

int main()
try
{
    vector<vector<int>> graph;
    vector<int> info;
    int n=1;
    for (int i=12; i>0; i--)
    {
        info=find_num(n);
        n=n*2;
        graph.push_back(info);
        if (delim!='a')
        {
            cout<<"enter ! to quit, enter a to autocomplete, r to turn on random number and guess, or anything other char to continue\n";
            cin>>delim;
            if (delim=='!')
                break;
        }
    }

    cout<<"Game Statistics\n\n";
    for (int i=0; i<graph.size(); ++i) // first set of numbers = to range_2
    {
        cout<<"range: "<<graph[i][0]<<" guessed number: "<<graph[i][1]<<" number of guesses: "<<graph[i][2]<<"\n";
        cout<<"the worst case scenario using midpoints for this range is "<<max(graph[i][0])<<"\n\n";
    }
    cout<<"\n\n\n";
    for (int i=1; i<graph.size(); ++i) //second set of numbers = to range_2-1
    {
        cout<<"range: "<<graph[i][3]<<" guessed number: "<<graph[i][4]<<" number of guesses: "<<graph[i][5]<<"\n";
        cout<<"the worst case scenario using midpoints for this range is "<<max(graph[i][0])<<"\n\n";
    }

    return 0;
}



catch(int)
{
    cout<<"exception: guess out of range";

    return  1;
}

catch(...)
{
    cout<<"exception occured!\n";
    return 2;
}
